import hola from `./productos.js`
import {productosMascotas} from `./productos.js`

const contenedorProductos = document.getElementById(`contenedor-productos`)

renderizarCatalogo(contenedorProductos, productosMascotas)